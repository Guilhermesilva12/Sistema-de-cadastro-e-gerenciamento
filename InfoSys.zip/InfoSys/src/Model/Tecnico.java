
package Model;

import DAO.TecnicoDAO;
import java.util.List;
import javax.swing.table.DefaultTableModel;


public class Tecnico {
    
   
    
    private int codigo = 0;
    private String nome;
    private double salario,valor;
    
    
    public Tecnico(String nome, double salario,double valor){
        this.setNome(nome);
        this.setSalario(salario);
        this.setValor(valor);
        gravar();
    }
    
    
    public Tecnico(int codigo, String nome, double salario,double valor){
        this.setNome(nome);
        this.setSalario(salario);
        this.setValor(valor);
    }
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
     public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        String retorno;
        
        retorno = "Código:..." + this.getCodigo() + "\n" +
                  "Nome:..." + this.getNome() + "\n" +
                  "Salário:..." + this.getSalario() + "\n" +
                  "Valor:..." + this.getValor();

        return retorno;
    }
    
    private void gravar(){
        TecnicoDAO dao = new TecnicoDAO();
        int codigo = dao.insert(this);
        if(codigo > 0) setCodigo(codigo);
    }
    
    public static DefaultTableModel getTableModel(){
        
        List<Tecnico> lista = TecnicoDAO.getInstance().read();
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Nome");
        modelo.addColumn("Salário");
        modelo.addColumn("Valor");
        
        for(Tecnico t : lista){
            String[] reg = {t.getNome(), t.getSalario() + "", t.getValor() + ""};
            modelo.addRow(reg);
        }
        return modelo;
    }
    
    
    
    
    
    
    
    
    
    
}
