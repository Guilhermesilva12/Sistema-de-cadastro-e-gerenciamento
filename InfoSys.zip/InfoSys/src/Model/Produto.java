
package Model;

import DAO.ProdutoDAO;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class Produto {
    
    
    
    private int codigo = 0;
    private String descricao;
    private int estoque;
    private boolean ativo;
    private double valor,custo;

    public Produto(String descricao, int estoque, boolean ativo, double valor, double custo) {
        this.setDescricao(descricao);
        this.setEstoque(estoque);
        this.setAtivo(ativo);
        this.setValor(valor);
        this.setCusto(custo);
        gravar();
    }
    
    public Produto(int codigo,String descricao, int estoque,double valor, double custo) {
        this.setDescricao(descricao);
        this.setEstoque(estoque);
        this.setValor(valor);
        this.setCusto(custo);
        
    }
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    

    public double getCusto() {
        return custo;
    }

    public void setCusto(double custo) {
        this.custo = custo;
    }
    
    
    @Override
    public String toString(){
        String retorno;
         retorno ="Descrição:..." +this.getCodigo() + "-"  + this.getDescricao() +"\n" +
                  "Estoque:....." + this.getEstoque()   +"\n" +
                  "Ativo:......." + (this.isAtivo() ? "S" : "N")    +"\n" +
                  "Valor:......." + this.getValor()     +"\n" +
                  "Custo:......." + this.getValor();
        return retorno;
    }
    
    
    private void gravar(){
        ProdutoDAO dao = new ProdutoDAO();
        int codigo = dao.insert(this);
        if(codigo > 0) setCodigo(codigo);
    }
    
    public static DefaultTableModel getTableModel(){
        
        List<Produto> lista = ProdutoDAO.getInstance().read();
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Descricão");
        modelo.addColumn("Estoque");
        modelo.addColumn("Valor");
        modelo.addColumn("Custo");
        
        for(Produto p : lista){
            String[] reg = {p.getDescricao(),p.getEstoque()+"",p.getValor() +"",p.getCusto()+""};
            modelo.addRow(reg);
        }
        return modelo;
    }

    
    
    
    
    
    
    
}
