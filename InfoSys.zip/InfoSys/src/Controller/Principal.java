
package Controller;


import Util.Configura;
import View.TelaCadastro;


public class Principal {
    
    
    //Autor do programa: Guilherme_Gomes_Fernandes_de_Oliveira_N592451_CC4P33_ALPOO_Prof Saulo e Luciano
    
    
    public static void main(String[] args) {
        
        Configura.LookAndFeel("Windows Classic");
        new TelaCadastro().setVisible(true);

        
    }
    
    
}
