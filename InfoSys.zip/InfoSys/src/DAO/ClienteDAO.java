
package DAO;

import Model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ClienteDAO implements Persistencia<Cliente> {
    
    private static ClienteDAO dao = null;

    @Override
    public int insert(Cliente c) {
        int               id  = 0;
        Connection        con = ConnectionFactory.getConnection();
        PreparedStatement pst = null;
        ResultSet         rs  = null;
        String            sql = "INSERT INTO Cliente (nome, cpf, fone, celular, email) VALUES (?, ?, ?, ?, ?)";
        try {
            pst = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            pst.setString(1, c.getNome());
            pst.setString(2, c.getCpf());
            pst.setString(3, c.getFone());
            pst.setString(4, c.getCelular());
            pst.setString(5, c.getEmail());
            pst.execute();
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        }
        catch (SQLException ex) {
            id = 0;
        } finally{
            ConnectionFactory.closeConnection(con, pst, rs);
        }
        return id;
    }
    
    
    

    @Override
    public List<Cliente> read() {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM Cliente ORDER BY nome";
        List lista = new ArrayList<Cliente>();
        
        try{
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            
            while(rs.next()){
                int codigo = rs.getInt("codigo");
                String nome = rs.getString("nome");
                String cpf = rs.getString("cpf");
                String fone = rs.getString("fone");
                String celular = rs.getString("celular");
                String email = rs.getString("email");
                lista.add(new Cliente(codigo,nome,cpf,fone,celular,email));
            }
            
            
        } catch(SQLException ex){
            throw new RuntimeException("Erro no SELECT");
        } finally{
            ConnectionFactory.closeConnection(con, pst, rs);
        }
        return lista;  
    }
    
    public static ClienteDAO getInstance(){
        if (dao == null) dao = new ClienteDAO();
        return dao;
    }

    
    
    
    
    
    
}
