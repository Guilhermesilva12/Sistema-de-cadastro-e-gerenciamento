
package DAO;

import java.util.List;

public interface Persistencia<T> {
    
    public int insert (T obj);
    public List<T> read();
    
    
    
}
