
package DAO;

import Model.Tecnico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class TecnicoDAO implements Persistencia<Tecnico> {
    
    private static TecnicoDAO dao = null;

    @Override
    public int insert(Tecnico t) {
        
        int               id  = 0;
        Connection        con = ConnectionFactory.getConnection();
        PreparedStatement pst = null;
        ResultSet         rs  = null;
        String            sql = "INSERT INTO Tecnico (nome, salario, valor) VALUES (?, ?, ?)";
        try {
            pst = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            pst.setString(1, t.getNome());
            pst.setDouble(2, t.getSalario());
            pst.setDouble(3, t.getValor());
            pst.execute();
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        }
        catch (SQLException ex) {
            id = 0;
        } finally{
            ConnectionFactory.closeConnection(con, pst, rs);
        }
        return id;
        
    }

    @Override
    public List<Tecnico> read() {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM Tecnico ORDER BY nome";
        List lista = new ArrayList<Tecnico>();
        
        try{
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            
            while(rs.next()){
                int codigo = rs.getInt("codigo");
                String nome = rs.getString("Nome");
                double salario = Double.parseDouble(rs.getString("salario"));
                double valor = Double.parseDouble(rs.getString("valor"));
                lista.add(new Tecnico(codigo,nome,salario,valor));
            }
            
            
        } catch(SQLException ex){
            throw new RuntimeException("Erro no SELECT");
        } finally{
            ConnectionFactory.closeConnection(con, pst, rs);
        }
        return lista;  
    }
    
    public static TecnicoDAO getInstance(){
        if (dao == null) dao = new TecnicoDAO();
        return dao;
    }
    
    
}
