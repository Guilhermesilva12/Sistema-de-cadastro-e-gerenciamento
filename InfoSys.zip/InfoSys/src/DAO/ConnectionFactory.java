
package DAO;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class ConnectionFactory {
    // atributos
    private final static  String sgbd   = "mysql";
    private final static  String server = "localhost";
    private final static  String porta  = "3306";
    private final static  String user   = "root";
    private final static  String pw     = "admin123";
    private final static  String banco  = "InfoSys";    
    private final static  String strCnx = "jdbc:" + sgbd + "://" + server + ":" + porta + "/" + banco;
    // construtores
    public ConnectionFactory() { }
    // faz conexão
    public static Connection getConnection(){
        try {
            return DriverManager.getConnection(strCnx, user, pw);
        }
        catch(SQLException e) {
            throw new RuntimeException("Erro na conexão");
        }
    }
    
    public static void closeConnection(Connection con){
        try {
            if (con != null) con.close();
        }
        catch(SQLException e) {
            throw new RuntimeException("Erro no fechamento na conexão");
        }
    }
    
    public static void closeConnection(Connection con, PreparedStatement pst){
        try {
            if (pst != null) pst.close();
            closeConnection(con);
        }
        catch(SQLException e) {
            throw new RuntimeException("Erro no fechamento do statement");
        }
    }
    
    public static void closeConnection(Connection con, PreparedStatement pst, ResultSet rs){
        try {
            if (rs != null) rs.close();
            closeConnection(con,pst);
        }
        catch(SQLException e) {
            throw new RuntimeException("Erro no fechamento do result set");
        }
    }
}

