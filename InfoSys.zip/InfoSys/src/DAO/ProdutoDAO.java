
package DAO;

import Model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ProdutoDAO implements Persistencia<Produto> {
    
    private static ProdutoDAO dao = null;

    @Override
    public int insert(Produto p) {
        int               id  = 0;
        Connection        con = ConnectionFactory.getConnection();
        PreparedStatement pst = null;
        ResultSet         rs  = null;
        String            sql = "INSERT INTO Produto (descricao, estoque, custo, venda) VALUES (?, ?, ?, ?)";
        
        try {
            pst = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            pst.setString(1, p.getDescricao());
            pst.setInt(2, p.getEstoque());
            pst.setDouble(3, p.getCusto());
            pst.setDouble(4, p.getValor());
            pst.execute();
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        }
        catch (SQLException ex) {
            id = 0;
        } finally{
            ConnectionFactory.closeConnection(con, pst, rs);
        }
        return id;
        
    }

    @Override
    public List<Produto> read() {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM Produto ORDER BY descricao";
        List lista = new ArrayList<Produto>();
        
        try{
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            
            while(rs.next()){
                int codigo = rs.getInt("codigo");
                String descricao = rs.getString("descricao");
                int estoque = rs.getInt("estoque");
                double custo = Double.parseDouble(rs.getString("custo"));
                double venda = Double.parseDouble(rs.getString("venda"));
                lista.add(new Produto(codigo,descricao,estoque,custo,venda));
            }
            
            
        } catch(SQLException ex){
            throw new RuntimeException("Erro no SELECT");
        } finally{
            ConnectionFactory.closeConnection(con, pst, rs);
        }
        return lista; 
        
    }
    
    public static ProdutoDAO getInstance(){
        if ( dao == null) dao = new ProdutoDAO();
        return dao;
    }

   
    
}
